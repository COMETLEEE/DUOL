RTTR Examples
==============
> Variouse examples of how to use RTTR

The following projects shows how to use RTTR in some practical examples.
You can find more information on: <a target="_blank" href="http://www.rttr.org">www.rttr.org</a>

##### Following examples are available
1. serialization/deserialization with json
2. explicit loading of libraries at runtime
