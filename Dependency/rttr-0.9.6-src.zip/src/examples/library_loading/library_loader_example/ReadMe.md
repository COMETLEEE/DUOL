Plugin loading
==============

This example demonstrate the explicit loading of libraries.


